"""wallpaper-reddit package"""

from wpreddit import main
if __name__ == '__main__':
    main.run()
